# SyncSound

Turn every phone in the room into a speaker. One person hosts, everyone else
joins with a code or QR, the host uploads a track, and once every phone has
downloaded it and tapped "ready," playback starts on a scheduled clock so
every device drops on the same beat instead of a scattered echo.

This build keeps **every file in one folder** — no `src/`, no `public/`,
no `server/`. Just the files themselves.

## Files in this folder

```
server.js       Express + Socket.IO app, REST routes, playback events
rooms.js        In-memory room store
package.json    Dependencies (run npm install here)
index.html      Create / join screen
room.html       Room UI (host + members share this page)
style.css       Shared stylesheet for both pages
home.js         Create/join logic (used by index.html)
room.js         Sockets, clock sync, scheduled playback, chat (used by room.html)
uploads/        Uploaded audio files, created automatically, one subfolder per room code
README.md       This file
```

## How the sync actually works

1. The host uploads an audio file. The server stores it under `uploads/` and
   tells every connected phone where to download it from.
2. Each phone downloads the **whole file** before playback — no streaming
   mid-song, so there's nothing to buffer or stall on.
3. Each phone runs a small clock-sync handshake with the server (several
   quick round trips) to estimate the offset between its own clock and the
   server's.
4. When the host presses play, the server broadcasts a timestamp ~3 seconds
   in the future instead of "play now." Every phone converts that into its
   own local clock using the offset from step 3, counts down, and calls
   `play()` at that instant.

## Running it

```bash
npm install
npm start
```

Then open `http://localhost:3000` in your browser to create a room. This
**must** be opened through that address (not by double-clicking `room.html`
as a local file) — the app needs the Node server running for Socket.IO, the
API routes, and the QR code to work.

## Testing real multi-device sync

`localhost` only works on the same machine. To test with multiple phones:

1. Find your computer's LAN IP address (e.g. `192.168.1.42`) — on Mac/Linux
   run `ifconfig` or `ip addr`, on Windows run `ipconfig`.
2. Start the server as above.
3. On your phone (same Wi-Fi network), open `http://<that-ip>:3000`.
4. Create a room on your computer, join it from your phone (or scan the QR
   code shown in the room), upload a track, mark every device ready, and hit
   play from the host's screen.

## What's implemented

- Room creation with a 6-character code and a one-time host token
- Optional room password, and a host-controlled lock toggle
- QR code (generated server-side) that deep-links straight to the join screen
- Audio upload, stored per-room, streamed to `<audio>` elements client-side
- Device "ready" check — the host can't press play until everyone has
  downloaded the track and tapped ready (which also unlocks autoplay on
  that device, since browsers require a user gesture first)
- Clock-sync handshake + scheduled play/seek so playback starts together
  regardless of each phone's network latency
- Playlist + skip
- Live chat and floating emoji reactions
- Automatic host transfer if the host disconnects
- Live waveform visualizer per device (Web Audio API `AnalyserNode`)

## Note on this flat layout

`server.js` serves this whole folder as static files so `index.html`,
`room.html`, `style.css`, `home.js`, and `room.js` are all reachable — but it
explicitly blocks `server.js`, `rooms.js`, `package.json`, and this README
from being served, so your source code and dependency list aren't exposed
to visitors.

## What you'd add for production

- Swap the in-memory `rooms.js` store for Redis if you need more than one
  server process (the room code becomes a shared key)
- Swap local disk storage for Cloudflare R2 / S3 (the `multer.diskStorage`
  block in `server.js` is where you'd swap in an S3-compatible engine)
- Add HTTPS (put this behind a reverse proxy like Caddy or nginx, or a host
  that terminates TLS for you — Socket.IO and the Web Audio API both
  generally expect a secure context outside of `localhost`)
- Rate limiting on room creation and uploads
- A persistent database (Postgres/Mongo) if rooms need to survive a server
  restart
